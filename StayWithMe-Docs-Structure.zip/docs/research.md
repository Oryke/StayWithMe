# Research

> Research notes and findings.
