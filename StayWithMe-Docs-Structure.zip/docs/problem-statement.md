# Problem Statement

> Define the problem StayWithMe aims to solve.
