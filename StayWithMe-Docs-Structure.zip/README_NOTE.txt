Upload the markdown files into the root of your StayWithMe repository.
